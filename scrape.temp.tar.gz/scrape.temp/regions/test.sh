#!/bin/sh
sh find_parent.sh regions.json USA
sleep 3

sh find_parent.sh regions.json fr
sleep 3

sh find_parent.sh regions.json JAP
sleep 3

sh find_parent.sh regions.json eur
sleep 3