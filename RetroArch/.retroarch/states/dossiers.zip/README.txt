Onion help file 
Console <> Save folder

ARCADE		FB Alpha
ATARI		Stella 2014
COLECO		blueMSX
CPC		CrocoDS
DOS		DOSBox
FAIRCHILD	FreeChaF
FC		FCEUmm
FDS		FCEUmm
GB		Gambatte
GBA		gpSP
GBC		Gambatte
GG		PicoDrive
GW		GW
INTELLIVISION	FreeIntv
LYNX		Handy
MD		PicoDrive
MEGADUCK	SameDuck
MS		PicoDrive
MSX		blueMSX
NEOCD		NeoCD
NEOGEO		FinalBurn Neo
NGP		Beetle NeoPop
ODYSSEY		O2EM
PCE		Beetle PCE Fast
PCECD		Beetle PCE Fast
PICO		Retro8
POKE		PokeMini
PSX		PCSX-ReARMed
SCUMMVM		ScummVM
SEGACD		PicoDrive
SEGASTONE	PicoDrive
SEVENTHYEIGHT	ProSystem
SFC		Beetle Supafaust
SGFX		Beetle SuperGrafx
SUPERVISION	Potator
THRITYTWOX	PicoDrive
VB		Beetle VB
VECRTEX		vecx
WS		Beetle WonderSwan
ZXS		Fuse
