#ifndef THEME_H__
#define THEME_H__

#include "config.h"
#include "render.h"
#include "resources.h"

#endif // THEME_H__
