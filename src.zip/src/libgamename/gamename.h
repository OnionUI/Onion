
const char * GetGameName(const char * langname, const char * key);

#ifdef __cplusplus
extern "C" {
#endif
const char * GetGameNameForC(const char * langname, const char * key);
#ifdef __cplusplus
}; // end of extern "C"
#endif
