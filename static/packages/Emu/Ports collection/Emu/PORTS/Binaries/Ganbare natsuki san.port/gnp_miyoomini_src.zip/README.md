Ganbare Natsuki-San
==========================

Ganbare Natsuki-San is a game by Alpha Secret Base (now inactive).

It was officially ported to Windows, Debian (as a binary), Mac OSX, GP2X,
as well as a proprietary port for Xbox 360.

Unofficially, it was ported to the Sony PSP, Wiz, Caanoo, Dingoo and OpenPandora.
My version is based on the (partially) translated PSP version.

This source code builds and works for the GCW-Zero, RS-97, and the new Bittboy.
Other platforms are planned too.

Some bugs were fixed as well, with the aim of making the game portable.
Here are some of the changes :
  * Fixed support for 64-bits platforms
  * Loads 32-bitsz backgrounds instead of the 8-bits ones. (An error in the source code)

LICENSE
========

GNP is licensed under a BSD-like license. See COPYRIGHT file for more information.
