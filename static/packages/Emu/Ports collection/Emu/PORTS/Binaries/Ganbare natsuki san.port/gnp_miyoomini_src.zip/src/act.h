#ifndef __ACT
#define __ACT

extern void act_main( void );

#endif
