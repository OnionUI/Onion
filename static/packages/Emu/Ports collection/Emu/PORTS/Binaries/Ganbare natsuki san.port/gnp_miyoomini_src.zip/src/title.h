#ifndef __TITLE
#define __TITLE

extern void title_main( void );

#endif
