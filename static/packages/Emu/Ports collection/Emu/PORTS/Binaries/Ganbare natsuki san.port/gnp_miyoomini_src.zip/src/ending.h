#ifndef __ENDING
#define __ENDING

extern void ending_main( void );

#endif
