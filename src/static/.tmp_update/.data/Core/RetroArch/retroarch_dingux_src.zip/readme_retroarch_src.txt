This source is the diff from this version: https://github.com/libretro/RetroArch/releases/tag/v1.10.3
Makefile is based on Makefile.miyoo/dingux
MI libraries and headres are in SYSROOT/usr/lib , SYSROOT/usr/include/sdkdir
dingux_utils.c is taken from https://github.com/TechDevangelist/RetroArch
