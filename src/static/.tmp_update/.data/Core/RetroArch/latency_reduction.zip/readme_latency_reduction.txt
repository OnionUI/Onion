Latency reduction mod for miyoomini-220419FW when AudioFix : ON

Usage:
Turn off device first.
Copy 3 files "audioserver"(overwrite) , "audioserver.mod" , "as_preload.so" to /miyoo/app in SD.
Then boot.

If the delay of the cursor movement sound is gone, it's successful :)

"audioserver.org" is original audioserver, use this when you want to revert back to the original.
