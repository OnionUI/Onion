---
name: Bug Reports Only (Feature requests should be raised in the 'Discussions' tab
  above)
about: Report a defect to help us improve Onion
title: ''
labels: ''
assignees: ''

---

**Describe the bug**

Replace this line with a clear and concise description of what the bug is

**To Reproduce**

Replace this line with the steps to reproduce the behaviour:

**Software (please complete the following information):**

 - Onion OS version: [e.g. 3.11.2]
 - Miyoo Firmware version: [e.g. 0419]

**Additional context**

Add any other context about the problem here (add screenshots or attachments if required).
